package com.example.test.Model;

import java.util.Date;

public class BookForm {
    private String id;
    private String name;
    private String surname;
    private String contact;
    private String email;
    private String ticketType;

    public BookForm() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public BookForm(String id, String name, String surname, String contact, String email, String ticketType) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.contact = contact;
        this.email = email;
        this.ticketType = ticketType;
    }
}