package com.example.test;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Signin2 extends AppCompatActivity {

    EditText edtEmail, edtPassword;
    Button btnSignIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin2);

        // Initialize EditText and Button
        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
        btnSignIn = findViewById(R.id.btnSignIn);

        // Set click listener for the Sign In button
        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signIn();
            }
        });
    }

    // Method to handle sign in
    private void signIn() {
        // Get the email and password entered by the user
        String email = edtEmail.getText().toString().trim();
        String password = edtPassword.getText().toString().trim();

        // Check if email or password is empty
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Add your sign-in logic here
        // For example, you can display a progress dialog and then authenticate the user using Firebase Authentication
        // After successful authentication, you can navigate to the desired activity

        // Display a progress dialog while signing in
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Signing In...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        // Perform sign-in authentication
        // Replace the code below with your own authentication logic (e.g., using Firebase Authentication)
        // For demonstration purposes, this code simulates a successful sign-in
        // In a real application, you would authenticate the user using Firebase Authentication or another authentication mechanism
        // If authentication is successful, you can navigate to the desired activity
        // If authentication fails, you can display an error message

        // Simulate a successful sign-in (for demonstration purposes)
        // Replace this code with your own authentication logic (e.g., Firebase Authentication)
        // In a real application, you would authenticate the user using Firebase Authentication or another authentication mechanism
        // After authentication, you can navigate to the desired activity

        // Dismiss the progress dialog
        progressDialog.dismiss();

        // Display a toast message indicating successful sign-in (for demonstration purposes)
        Toast.makeText(this, "Sign In Successful!", Toast.LENGTH_SHORT).show();

        // Navigate to the Home2 activity
        Intent intent = new Intent(Signin2.this, Home2.class);
        startActivity(intent);
        finish(); // Close the current activity
}
}